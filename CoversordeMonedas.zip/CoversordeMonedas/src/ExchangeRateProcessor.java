import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.util.Map;
import java.util.HashMap;

public class ExchangeRateProcessor {

    /**
     * Método para filtrar tasas de cambio según una lista de códigos de moneda.
     *
     * @param jsonResponse Respuesta JSON de la API como String.
     * @param currencyCodes Lista de códigos de moneda a filtrar.
     * @return Mapa con los códigos de moneda y sus tasas de cambio.
     */
    public static Map<String, Double> filtrarTasasDeCambio(String jsonResponse, String[] currencyCodes) {
        // Parsear la respuesta JSON
        JsonObject jsonObject = JsonParser.parseString(jsonResponse).getAsJsonObject();
        JsonObject conversionRates = jsonObject.getAsJsonObject("conversion_rates");

        // Crear un mapa para almacenar las monedas filtradas
        Map<String, Double> filteredRates = new HashMap<>();

        for (String code : currencyCodes) {
            if (conversionRates.has(code)) {
                filteredRates.put(code, conversionRates.get(code).getAsDouble());
            }
        }

        return filteredRates;
    }
}