import com.google.gson.Gson;

public class PruebaConfiguracion {
    public static void main(String[] args) {
        // Crear un objeto simple para convertir a JSON
        String[] monedas = {"USD", "EUR", "MXN"};
        Gson gson = new Gson();
        String json = gson.toJson(monedas);

        // Imprimir el JSON para verificar que Gson funciona
        System.out.println("JSON de prueba: " + json);
    }
}
