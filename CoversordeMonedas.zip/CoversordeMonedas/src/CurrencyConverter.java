import java.util.Map;

public class CurrencyConverter {

    /**
     * Método para realizar la conversión entre dos monedas.
     *
     * @param amount Cantidad a convertir.
     * @param fromRate Tasa de cambio de la moneda origen (respecto al USD).
     * @param toRate Tasa de cambio de la moneda destino (respecto al USD).
     * @return El resultado de la conversión.
     */
    public static double convertirMoneda(double amount, double fromRate, double toRate) {
        if (fromRate == 0 || toRate == 0) {
            throw new IllegalArgumentException("Las tasas de cambio no pueden ser cero.");
        }
        return (amount / fromRate) * toRate;
    }

    /**
     * Método para mostrar el resultado de la conversión.
     *
     * @param amount Cantidad original.
     * @param from Moneda origen.
     * @param to Moneda destino.
     * @param result Resultado de la conversión.
     */
    public static void mostrarResultado(double amount, String from, String to, double result) {
        System.out.printf("%.2f %s equivalen a %.2f %s\n", amount, from, result, to);
    }
}