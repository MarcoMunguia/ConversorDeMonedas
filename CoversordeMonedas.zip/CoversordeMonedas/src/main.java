import java.util.Scanner;

public class main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean continuar = true;

        while (continuar) {
            // Mostrar menú de opciones
            System.out.println("***************************************************************************");
            System.out.println("Sea bienvenido/a al Conversor de Monedas");
            System.out.println("1) Dólar => Peso Mexicano");
            System.out.println("2) Peso Mexicano => Dólar");
            System.out.println("3) Dólar => Real Brasileño");
            System.out.println("4) Real Brasileño => Dólar");
            System.out.println("5) Dólar => Peso Colombiano");
            System.out.println("6) Peso Colombiano => Dólar");
            System.out.println("7) Salir");
            System.out.println("***************************************************************************");
            System.out.print("Elija una opción válida: ");

            // Capturar opción del usuario
            int opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    realizarConversion(scanner, "USD", "MXN");
                    break;
                case 2:
                    realizarConversion(scanner, "MXN", "USD");
                    break;
                case 3:
                    realizarConversion(scanner, "USD", "BRL");
                    break;
                case 4:
                    realizarConversion(scanner, "BRL", "USD");
                    break;
                case 5:
                    realizarConversion(scanner, "USD", "COP");
                    break;
                case 6:
                    realizarConversion(scanner, "COP", "USD");
                    break;
                case 7:
                    System.out.println("Gracias por usar el Conversor de Monedas. ¡Hasta luego!");
                    continuar = false;
                    break;
                default:
                    System.out.println("Por favor, seleccione una opción válida.");
            }
        }

        scanner.close();
    }

    /**
     * Método para realizar la conversión entre dos monedas.
     *
     * @param scanner     Objeto Scanner para capturar entrada del usuario.
     * @param fromCurrency Moneda origen.
     * @param toCurrency   Moneda destino.
     */
    public static void realizarConversion(Scanner scanner, String fromCurrency, String toCurrency) {
        System.out.print("Ingrese la cantidad a convertir: ");
        double cantidad = scanner.nextDouble();

        if (cantidad <= 0) {
            System.out.println("La cantidad debe ser un número positivo.");
            return;
        }

        // Aquí debes llamar al método para obtener tasas de cambio y realizar el cálculo.
        // Por simplicidad, usamos tasas fijas en este ejemplo.
        double tasa = obtenerTasaFicticia(fromCurrency, toCurrency);
        double resultado = cantidad * tasa;

        System.out.printf("%.2f %s equivalen a %.2f %s\n", cantidad, fromCurrency, resultado, toCurrency);
    }

    /**
     * Método ficticio para simular la obtención de tasas de cambio.
     * Reemplazar con llamada real a la API en la integración final.
     *
     * @param fromCurrency Moneda origen.
     * @param toCurrency   Moneda destino.
     * @return Tasa de cambio ficticia.
     */
    public static double obtenerTasaFicticia(String fromCurrency, String toCurrency) {
        if (fromCurrency.equals("USD") && toCurrency.equals("MXN")) {
            return 20.5;
        } else if (fromCurrency.equals("MXN") && toCurrency.equals("USD")) {
            return 0.0488;
        } else if (fromCurrency.equals("USD") && toCurrency.equals("BRL")) {
            return 5.2;
        } else if (fromCurrency.equals("BRL") && toCurrency.equals("USD")) {
            return 0.19;
        } else if (fromCurrency.equals("USD") && toCurrency.equals("COP")) {
            return 4000.0;
        } else if (fromCurrency.equals("COP") && toCurrency.equals("USD")) {
            return 0.00025;
        }
        return 1.0; // Tasa por defecto
    }
}
