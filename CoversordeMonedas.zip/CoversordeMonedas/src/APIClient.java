import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.URI;

public class APIClient {
    private static final String BASE_URL = "https://v6.exchangerate-api.com/v6/c3f5f8491a01018181fbafbd/latest/USD";

    public static String fetchExchangeRates() throws Exception {
        // Crear un cliente HttpClient
        HttpClient client = HttpClient.newHttpClient();

        // Crear una solicitud HttpRequest
        HttpRequest request = HttpRequest.newBuilder()
                .uri(new URI(BASE_URL))
                .header("Accept", "application/json") // Solicitar JSON
                .GET()
                .build();

        // Enviar la solicitud y obtener la respuesta
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

        // Verificar el código de estado
        int statusCode = response.statusCode();
        if (statusCode == 200) {
            System.out.println("Solicitud exitosa. Código de estado: " + statusCode);
            System.out.println("Encabezados: " + response.headers());
            return response.body(); // Retornar el cuerpo de la respuesta
        } else {
            throw new Exception("Error en la solicitud: Código de estado " + statusCode);
        }
    }
}